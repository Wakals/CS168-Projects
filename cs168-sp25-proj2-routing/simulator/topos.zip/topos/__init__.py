"""
Topologies, topology generators, etc.

For help on a specific one, try help(topos.topo_name).  You may need to
import it first, e.g.:

  import topos.candy
  help(topos.candy)
"""
